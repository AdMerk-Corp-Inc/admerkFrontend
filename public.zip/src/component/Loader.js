import React from 'react'

export default function Loader() {
    return (
        <div className='loader-div'>
            <img src="/assets/images/loader1.gif" alt="" />
        </div>
    )
}
